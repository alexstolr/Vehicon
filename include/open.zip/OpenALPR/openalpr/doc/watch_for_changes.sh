#!/bin/bash


find source/ | entr ./generate 
